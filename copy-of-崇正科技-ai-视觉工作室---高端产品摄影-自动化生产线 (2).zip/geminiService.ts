import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SceneStyle, EnvironmentType, ImageSize, ImageTaskType } from "./types";

const getAIClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const getStrictIdentityProtocol = () => `
[STRICT IDENTITY PROTOCOL]
- RETAIN the product's exact physical form, dimensions, and texture.
- NO DEFORMATION: The product must not bend, stretch, or warp.
- PERSPECTIVE ALIGNMENT: Adjust the perspective of the product to match the specified camera angle perfectly.
`;

export const generateRandomProductPrompt = async (): Promise<string> => {
  const ai = getAIClient();
  const prompt = `作为一名资深电商摄影师，请随机提供一个高端、极简的产品描述词。仅包含产品名称、材质和造型。不超过20字。`;
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ parts: [{ text: prompt }] }]
  });
  return response.text.trim() || "一套极简主义风格的白色骨瓷茶具";
};

export const generateOriginalProduct = async (
  productDescription: string,
  size: ImageSize = ImageSize.SIZE_1K,
  usePro: boolean = false
): Promise<string> => {
  const ai = getAIClient();
  const modelName = usePro ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  const prompt = `TASK: PROFESSIONAL PRODUCT PHOTOGRAPHY. SUBJECT: ${productDescription}. STYLE: Studio white background, clean lighting.`;
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: modelName,
    contents: { parts: [{ text: prompt }] },
    config: usePro ? { imageConfig: { aspectRatio: "1:1", imageSize: size } } : undefined
  });
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("生成失败");
};

export const replaceBackground = async (
  base64Image: string,
  environment: EnvironmentType,
  style: SceneStyle,
  customPrompt: string,
  taskType: ImageTaskType,
  isPro: boolean = false,
  size: ImageSize = ImageSize.SIZE_1K,
  addReference: boolean = false,
  cleanProduct: boolean = false,
  addHuman: boolean = false
): Promise<string> => {
  const ai = getAIClient();
  const modelName = isPro ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  const envPrompts: Record<string, string> = {
    [EnvironmentType.AUTO_ADAPT]: "a contextually appropriate high-end environment that best complements the product",
    [EnvironmentType.PAIFANG_STREET]: "the historic Chaoshan Paifang Street with traditional stone arches",
    [EnvironmentType.BINJIANG_PROMENADE]: "the scenic Chaoshan Binjiang Promenade by the river",
    [EnvironmentType.PHOENIX_TIANCHI]: "the misty Phoenix Heaven Lake mountain top",
    [EnvironmentType.GUANGJI_BRIDGE]: "the ancient Guangji Bridge pavilions",
    [EnvironmentType.BEDROOM]: "a high-end luxury bedroom",
    [EnvironmentType.DINING_ROOM]: "an elegant dining room",
    [EnvironmentType.OUTDOOR_PICNIC]: "a sunny outdoor garden",
    [EnvironmentType.BATHROOM]: "a modern marble bathroom",
    [EnvironmentType.LIVING_ROOM]: "a designer living room",
    [EnvironmentType.OFFICE]: "a professional minimalist office",
    [EnvironmentType.STUDIO]: "a clean photography studio",
    [EnvironmentType.CAFE]: "a boutique urban cafe"
  };

  const stylePrompts: Record<string, string> = {
    [SceneStyle.AUTO_ADAPT]: "Natural commercial lighting, photorealistic textures, neutral aesthetic.",
    [SceneStyle.MODERN_LUXURY]: "Premium luxury, marble, gold accents, clean sharp lighting.",
    [SceneStyle.ZEN_MINIMALIST]: "Peaceful, organic textures, diffused lighting.",
    [SceneStyle.C4D_GEOMETRIC]: "Avant-garde 3D render style, abstract shapes.",
    [SceneStyle.WINDOW_LIGHT]: "Cinematic window light, soft ray tracing.",
    [SceneStyle.WARM_BOKEH]: "Warm cozy evening mood, rich bokeh.",
    [SceneStyle.BLACK_GOLD]: "Sultry dark mode, dramatic rim lighting.",
    [SceneStyle.CHAOZHOU_RETRO]: "Southern Chinese vintage textures, nostalgic architecture."
  };

  let taskInstruction = "";
  let envWeight = "NORMAL";

  switch (taskType) {
    case 'VIEW_TOP':
      taskInstruction = `[TASK: TOP-DOWN VIEW] Flat lay perspective.`;
      break;
    case 'VIEW_SIDE':
      taskInstruction = `[TASK: 45-DEGREE SIDE VIEW] Showing depth and profile.`;
      break;
    case 'DETAIL_MACRO':
      envWeight = "LOW";
      taskInstruction = `[TASK: MACRO FOCUS] Extreme close-up on surface texture.`;
      break;
    case 'AD_POSTER':
      taskInstruction = `[TASK: HEROIC AD VIEW] Low-angle grand commercial aesthetic.`;
      break;
    case 'AD_NEGATIVE':
      taskInstruction = `[TASK: COMPOSITIONAL NEGATIVE SPACE] Rule of thirds, product on side.`;
      break;
    default:
      taskInstruction = `[TASK: ICONIC FRONT VIEW] Straight-on eye-level catalog view.`;
  }

  const cleanCmd = cleanProduct ? "RETCH: Ensure product surface is pristine." : "";
  const refCmd = (addReference && envWeight !== "LOW") ? "SCALE: Add a blurry household object for size comparison." : "";
  
  // 优化后的人物介入逻辑：改为强调氛围而非强制性抓握
  const humanCmd = addHuman ? `HUMAN LIFESTYLE: Integrate a natural human presence or organic interaction in a candid, lifestyle manner. Avoid stiff posing. A person may be partially visible, in soft focus background, or naturally engaging with the context. The product MUST remain the clear focal point and not be obscured.` : "";

  const finalPrompt = `
    ${getStrictIdentityProtocol()}
    ${taskInstruction}
    ${envWeight !== "LOW" ? `ENVIRONMENT: In ${envPrompts[environment]}.` : ""}
    VISUAL STYLE: ${stylePrompts[style]}
    ${humanCmd}
    ${cleanCmd}
    ${refCmd}
    ${customPrompt ? `EXTRA_DETAIL: ${customPrompt}` : ""}
    PHOTOGRAPHY: Photorealistic, 8k, sharp focus.
  `;

  const maxRetries = 2;
  let lastError: any;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [{ parts: [{ inlineData: { mimeType: 'image/jpeg', data: base64Image.split(',')[1] || base64Image } }, { text: finalPrompt }] }],
        config: isPro ? { imageConfig: { aspectRatio: "1:1", imageSize: size } } : undefined
      });

      const base64 = response.candidates?.[0]?.content?.parts.find(p => p.inlineData)?.inlineData?.data;
      if (!base64) throw new Error("AI未能生成图像");
      return `data:image/png;base64,${base64}`;
    } catch (error: any) {
      lastError = error;
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }
  }
  throw lastError;
};