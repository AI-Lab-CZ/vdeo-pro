import React, { useState, useRef } from 'react';
import { 
  Upload, Sparkles, Download, MessageSquare, X, ChevronRight, RefreshCw, Box, Check, Zap, Layers, Camera, Focus, Trophy, ImageIcon, Compass, ArrowDownCircle, Maximize2, Dices, Archive, Columns, Loader2, UserPlus, MousePointer2
} from 'lucide-react';
import { SceneStyle, EnvironmentType, ImageSize, GenerationConfig, ChatMessage, GenerationResult, ImageTaskType } from './types';
import { replaceBackground, generateOriginalProduct, generateRandomProductPrompt } from './geminiService';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import JSZip from 'jszip';

const createComparisonImage = async (originalUrl: string, generatedUrl: string): Promise<string> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img1 = new Image();
    const img2 = new Image();
    img1.onload = () => {
      img2.onload = () => {
        const gap = 20;
        const width = img1.width + img2.width + gap; 
        const height = Math.max(img1.height, img2.height);
        canvas.width = width;
        canvas.height = height;
        if (ctx) {
            ctx.fillStyle = '#0a0a0a';
            ctx.fillRect(0, 0, width, height);
            ctx.drawImage(img1, 0, 0);
            ctx.drawImage(img2, img1.width + gap, 0);
            ctx.font = 'bold 40px Inter, Arial';
            ctx.shadowColor = "rgba(0,0,0,0.8)";
            ctx.shadowBlur = 10;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            ctx.fillText("BEFORE", 30, 60);
            ctx.fillStyle = '#6366f1'; 
            ctx.fillText("AFTER", img1.width + gap + 30, 60);
            resolve(canvas.toDataURL('image/jpeg', 0.92));
        }
      };
      img2.src = generatedUrl;
    };
    img1.crossOrigin = "anonymous";
    img2.crossOrigin = "anonymous";
    img1.src = originalUrl;
  });
};

const ALL_TASKS: {type: ImageTaskType, label: string, icon: any}[] = [
  { type: 'FRONT_HERO', label: '正面主图', icon: Camera },
  { type: 'VIEW_SIDE', label: '侧侧视角', icon: MousePointer2 },
  { type: 'VIEW_TOP', label: '俯拍视角', icon: ArrowDownCircle },
  { type: 'DETAIL_MACRO', label: '细节微距', icon: Focus },
  { type: 'AD_POSTER', label: '海报大片', icon: Trophy },
  { type: 'AD_NEGATIVE', label: '商业留白', icon: ImageIcon },
];

const App: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState({ current: 0, total: 0, label: '' });
  const [isGeneratingPrompt, setIsGeneratingPrompt] = useState(false);
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [isZippingRefined, setIsZippingRefined] = useState(false);
  const [isZippingComparison, setIsZippingComparison] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [previewImage, setPreviewImage] = useState<{url: string, label: string} | null>(null);
  
  const [config, setConfig] = useState<GenerationConfig>({
    environment: EnvironmentType.AUTO_ADAPT,
    style: SceneStyle.AUTO_ADAPT,
    customPrompt: '',
    isPro: false,
    size: ImageSize.SIZE_1K,
    addReference: true,
    cleanProduct: true,
    addHuman: false,
    selectedTasks: ALL_TASKS.map(t => t.type), // 默认全选
    mode: 'UPLOAD',
    productPrompt: '正在等待上传...',
    plan: 'PRO_SET'
  });
  
  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const getSafeFileName = (suffix: string) => {
    const baseName = config.productPrompt || '未命名产品';
    const safeName = baseName.slice(0, 20).trim().replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '_');
    return `${safeName}_${suffix}`;
  };

  const base64ToBlob = (base64: string) => {
    const parts = base64.split(';base64,');
    const contentType = parts[0].split(':')[1];
    const raw = window.atob(parts[1]);
    const uInt8Array = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; ++i) uInt8Array[i] = raw.charCodeAt(i);
    return new Blob([uInt8Array], { type: contentType });
  };

  const handleRandomPrompt = async () => {
    setIsGeneratingPrompt(true);
    try {
      const randomPrompt = await generateRandomProductPrompt();
      setConfig(prev => ({ ...prev, productPrompt: randomPrompt }));
    } catch (error) {
      console.error("生成灵感失败:", error);
    } finally {
      setIsGeneratingPrompt(false);
    }
  };

  const recognizeProduct = async (base64: string) => {
    setIsRecognizing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const prompt = "请识别这张图片中的产品主体。仅返回该产品的名称，要求：中文、简洁、高端。";
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [{ inlineData: { mimeType: 'image/jpeg', data: base64.split(',')[1] || base64 } }, { text: prompt }]
        }
      });
      const recognizedName = response.text.trim();
      if (recognizedName) setConfig(prev => ({ ...prev, productPrompt: recognizedName }));
    } catch (error) { console.error(error); } finally { setIsRecognizing(false); }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setSelectedFile(base64);
        setResult(null);
        recognizeProduct(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleTask = (type: ImageTaskType) => {
    setConfig(prev => {
      const isSelected = prev.selectedTasks.includes(type);
      return {
        ...prev,
        selectedTasks: isSelected 
          ? prev.selectedTasks.filter(t => t !== type)
          : [...prev.selectedTasks, type]
      };
    });
  };

  const handleGenerate = async () => {
    if (config.selectedTasks.length === 0) {
      alert("请至少选择一个视角");
      return;
    }
    setIsProcessing(true);
    setProcessingProgress({ current: 0, total: config.selectedTasks.length, label: '准备中...' });
    
    try {
      let baseImage = selectedFile;
      if (config.mode === 'AI_GEN') {
        setProcessingProgress(prev => ({ ...prev, label: '正在生成 AI 原型...' }));
        baseImage = await generateOriginalProduct(config.productPrompt, config.size, config.isPro);
        setSelectedFile(baseImage);
      }
      
      if (!baseImage) {
        alert("请上传或输入描述");
        setIsProcessing(false);
        return;
      }

      const tasksToRun = ALL_TASKS.filter(t => config.selectedTasks.includes(t.type));
      const generatedImages: any[] = [];

      for (let i = 0; i < tasksToRun.length; i++) {
        const task = tasksToRun[i];
        setProcessingProgress({ 
          current: i + 1, 
          total: tasksToRun.length, 
          label: `正在生成: ${task.label}` 
        });

        // 增加任务间隔以避开速率限制
        if (i > 0) {
          const delay = config.isPro ? 2500 : 800; // Pro 模式 2.5s, 普通模式 0.8s
          await new Promise(resolve => setTimeout(resolve, delay));
        }

        const url = await replaceBackground(
          baseImage!,
          config.environment,
          config.style,
          config.customPrompt,
          task.type,
          config.isPro,
          config.size,
          config.addReference,
          config.cleanProduct,
          config.addHuman
        );

        generatedImages.push({ 
          url, 
          type: task.type, 
          label: task.label, 
          description: config.addHuman ? '含人物交互场景' : '标准商业展示' 
        });
      }

      setResult({ originalUrl: baseImage, results: generatedImages, id: Date.now().toString() });
    } catch (error: any) {
      console.error(error);
      alert(`生成失败: ${error.message}`);
    } finally { 
      setIsProcessing(false); 
    }
  };

  const downloadAllAsZip = async () => {
    if (!result) return;
    setIsZippingRefined(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder(getSafeFileName("精修包"));
      folder?.file("00_原始图.png", base64ToBlob(result.originalUrl));
      result.results.forEach((res, i) => folder?.file(`${(i+1).toString().padStart(2,'0')}_${res.label}.png`, base64ToBlob(res.url)));
      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = `${getSafeFileName("精修包")}.zip`;
      link.click();
    } finally { setIsZippingRefined(false); }
  };

  const downloadAllComparisonsAsZip = async () => {
    if (!result) return;
    setIsZippingComparison(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder(getSafeFileName("对比包"));
      const promises = result.results.map(async (res, i) => {
        const comp = await createComparisonImage(result.originalUrl, res.url);
        folder?.file(`${(i+1).toString().padStart(2,'0')}_${res.label}_对比.jpg`, base64ToBlob(comp));
      });
      await Promise.all(promises);
      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = `${getSafeFileName("对比包")}.zip`;
      link.click();
    } finally { setIsZippingComparison(false); }
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    setChatMessages(prev => [...prev, { role: 'user', text: chatInput }]);
    setChatInput('');
    setIsChatting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: chatInput }] }],
        config: { systemInstruction: "你是资深摄影总监。用中文回答。" }
      });
      setChatMessages(prev => [...prev, { role: 'model', text: response.text || '' }]);
    } finally { setIsChatting(false); chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#080808] text-white font-sans relative">
      <aside className="w-full md:w-[400px] border-r border-white/5 bg-[#0c0c0c] p-8 flex flex-col gap-6 overflow-y-auto z-10 shadow-2xl">
        <header className="flex items-center gap-4 mb-2">
          <div className="p-2.5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tight text-white">崇正视觉 PRO</h1>
            <p className="text-[10px] text-white/30 uppercase tracking-[0.2em]">Lifestyle Engine</p>
          </div>
        </header>

        {/* 模式选择 */}
        <section className="bg-white/5 p-1 rounded-2xl flex gap-1">
          <button onClick={() => setConfig({...config, mode: 'UPLOAD'})} className={`flex-1 py-2 rounded-xl text-[10px] font-bold transition-all ${config.mode === 'UPLOAD' ? 'bg-indigo-600 text-white' : 'text-white/40'}`}>实拍上传</button>
          <button onClick={() => setConfig({...config, mode: 'AI_GEN'})} className={`flex-1 py-2 rounded-xl text-[10px] font-bold transition-all ${config.mode === 'AI_GEN' ? 'bg-indigo-600 text-white' : 'text-white/40'}`}>AI 创作</button>
        </section>

        {/* 上传区域 */}
        {config.mode === 'UPLOAD' && (
          <div className={`relative group cursor-pointer border-2 border-dashed ${selectedFile ? 'border-indigo-500/50' : 'border-white/5'} rounded-3xl aspect-square flex items-center justify-center overflow-hidden bg-white/[0.02]`}>
            {selectedFile ? <img src={selectedFile} className="w-full h-full object-contain p-4" /> : <div className="text-center p-6 flex flex-col items-center opacity-30 group-hover:opacity-100 transition-opacity"><Upload /><span className="text-[10px] mt-2 uppercase font-bold">上传产品原图</span></div>}
            <input type="file" onChange={handleFileUpload} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            {isRecognizing && <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center"><Loader2 className="animate-spin text-indigo-400 mb-2" /><span className="text-[10px] font-bold">识别产品中...</span></div>}
          </div>
        )}

        {/* 产品描述 */}
        <section className="space-y-4">
          <div className="relative">
            <label className="text-[10px] font-black text-white/20 uppercase tracking-widest ml-1 mb-1 block">
               {isRecognizing ? 'AI 识别中...' : '产品命名 / 描述'}
            </label>
            <textarea value={config.productPrompt} onChange={(e) => setConfig({...config, productPrompt: e.target.value})} className="w-full bg-white/[0.05] border border-white/10 rounded-2xl p-4 text-sm h-24 focus:ring-2 focus:ring-indigo-500/50 resize-none transition-all placeholder:text-white/10" placeholder="描述产品材质和造型..." />
            
            {/* 随机灵感按钮 */}
            <button 
              onClick={handleRandomPrompt}
              disabled={isGeneratingPrompt}
              className="absolute top-8 right-3 p-2 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-400 rounded-lg transition-all border border-indigo-500/30"
              title="随机灵感"
            >
              {isGeneratingPrompt ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Dices className="w-4 h-4" />}
            </button>
          </div>
        </section>

        {/* 视角勾选矩阵 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between ml-1">
            <label className="text-[10px] font-black text-white/40 uppercase tracking-widest">视角库 (自由勾选)</label>
            <span className="text-[10px] font-bold text-indigo-400">{config.selectedTasks.length} 个已选</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {ALL_TASKS.map(task => (
              <button 
                key={task.type}
                onClick={() => toggleTask(task.type)}
                className={`flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all ${config.selectedTasks.includes(task.type) ? 'bg-indigo-600/10 border-indigo-500/50 text-white' : 'bg-white/[0.02] border-white/5 text-white/20'}`}
              >
                <task.icon className={`w-4 h-4 ${config.selectedTasks.includes(task.type) ? 'text-indigo-400' : ''}`} />
                <span className="text-[9px] font-bold">{task.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 调控面板 */}
        <div className="space-y-3">
          <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-1">高级渲染控制</label>
          <div className="space-y-2">
            <button 
              onClick={() => setConfig({...config, isPro: !config.isPro})}
              className={`w-full flex items-center justify-between px-4 py-4 rounded-2xl text-[11px] font-bold border transition-all ${config.isPro ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white border-amber-400 shadow-lg shadow-amber-900/20' : 'bg-white/[0.02] border-white/5 text-white/30'}`}
            >
              <div className="flex items-center gap-3">
                <Zap className={`w-4 h-4 ${config.isPro ? 'text-white' : 'text-white/20'}`} />
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <span>PRO 模式</span>
                    {config.isPro && <span className="bg-white/20 px-1.5 py-0.5 rounded text-[8px]">ULTRA HD</span>}
                  </div>
                  <p className="text-[8px] opacity-60 font-medium">更高画质 | 支持 2K/4K | 消耗更多配额</p>
                </div>
              </div>
              {config.isPro ? <Check className="w-4 h-4" /> : <ChevronRight className="w-4 h-4 opacity-20" />}
            </button>

            {config.isPro && (
              <div className="grid grid-cols-3 gap-2 animate-in slide-in-from-top-2 duration-300">
                {Object.values(ImageSize).map(size => (
                  <button
                    key={size}
                    onClick={() => setConfig({...config, size})}
                    className={`py-2 rounded-xl text-[10px] font-bold border transition-all ${config.size === size ? 'bg-amber-500/20 border-amber-500/50 text-amber-400' : 'bg-white/[0.02] border-white/5 text-white/20'}`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 生活场景控制 */}
        <div className="space-y-3">
          <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-1">生活场景控制</label>
          <div className="space-y-2">
            <button 
              onClick={() => setConfig({...config, addHuman: !config.addHuman})}
              className={`w-full flex items-center justify-between px-4 py-4 rounded-2xl text-[11px] font-bold border transition-all ${config.addHuman ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-white/[0.02] border-white/5 text-white/30'}`}
            >
              <div className="flex items-center gap-3">
                <UserPlus className="w-4 h-4" />
                <span>人物介入 (Lifestyle)</span>
              </div>
              {config.addHuman && <Check className="w-4 h-4" />}
            </button>
            <div className="grid grid-cols-2 gap-2">
               <button onClick={() => setConfig({...config, cleanProduct: !config.cleanProduct})} className={`flex items-center justify-between px-4 py-3 rounded-xl text-[10px] font-bold border ${config.cleanProduct ? 'bg-indigo-600/10 border-indigo-500/50 text-indigo-400' : 'bg-white/[0.02] border-white/5 text-white/20'}`}>精修材质{config.cleanProduct && <Check className="w-3 h-3"/>}</button>
               <button onClick={() => setConfig({...config, addReference: !config.addReference})} className={`flex items-center justify-between px-4 py-3 rounded-xl text-[10px] font-bold border ${config.addReference ? 'bg-indigo-600/10 border-indigo-500/50 text-indigo-400' : 'bg-white/[0.02] border-white/5 text-white/20'}`}>空间比例{config.addReference && <Check className="w-3 h-3"/>}</button>
            </div>
          </div>
        </div>

        <section className="space-y-2">
          <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-1">空间 & 调性</label>
          <select value={config.environment} onChange={(e) => setConfig({...config, environment: e.target.value as EnvironmentType})} className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-3 py-3 text-xs appearance-none cursor-pointer">
            {Object.values(EnvironmentType).map(env => <option key={env} value={env} className="bg-neutral-900">{env}</option>)}
          </select>
          <select value={config.style} onChange={(e) => setConfig({...config, style: e.target.value as SceneStyle})} className="w-full bg-white/[0.05] border border-white/10 rounded-xl px-3 py-3 text-xs appearance-none cursor-pointer">
            {Object.values(SceneStyle).map(s => <option key={s} value={s} className="bg-neutral-900">{s}</option>)}
          </select>
        </section>

        <button 
          onClick={handleGenerate} 
          disabled={isProcessing}
          className={`w-full py-5 rounded-3xl font-bold text-sm flex flex-col items-center justify-center transition-all ${isProcessing ? 'bg-white/5 text-white/20' : 'bg-indigo-600 hover:shadow-indigo-600/30'}`}
        >
          {isProcessing ? <RefreshCw className="animate-spin mb-1" /> : <><Compass className="mb-1" /> <span>开始生成 {config.selectedTasks.length} 个视角</span></>}
        </button>
      </aside>

      <main className="flex-1 p-8 md:p-12 overflow-y-auto">
        {!result && !isProcessing && (
          <div className="h-full flex flex-col items-center justify-center opacity-10">
            <Maximize2 className="w-20 h-20 mb-4" />
            <p className="tracking-[0.8em] text-xs font-bold uppercase">Ready for Capture</p>
          </div>
        )}

        {isProcessing && (
          <div className="h-full flex flex-col items-center justify-center space-y-6">
            <div className="relative">
              <div className="w-24 h-24 border-t-2 border-indigo-500 rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-indigo-400">
                {Math.round((processingProgress.current / (processingProgress.total || 1)) * 100)}%
              </div>
            </div>
            <div className="text-center space-y-2">
              <p className="text-sm font-bold tracking-widest text-white uppercase animate-pulse">
                {processingProgress.label}
              </p>
              <p className="text-[10px] text-white/30 font-bold uppercase tracking-[0.2em]">
                正在处理第 {processingProgress.current} / {processingProgress.total} 个视角
              </p>
            </div>
          </div>
        )}

        {result && !isProcessing && (
          <div className="space-y-12 pb-24 animate-in fade-in duration-500">
            {/* 顶栏操作 */}
            <header className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-white/[0.02] p-8 rounded-[40px] border border-white/5">
              <div className="flex items-center gap-6">
                <img src={result.originalUrl} className="w-24 h-24 rounded-2xl object-contain bg-black border border-white/10" />
                <div>
                  <h2 className="text-xl font-bold">{config.productPrompt}</h2>
                  <p className="text-[10px] text-white/30 uppercase tracking-widest mt-1">
                    {config.selectedTasks.length} 视角 · {config.addHuman ? '含人物交互' : '纯净展示'}
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={downloadAllAsZip} disabled={isZippingRefined} className="px-6 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-xs font-bold flex items-center gap-2 border border-white/5">
                  {isZippingRefined ? <RefreshCw className="animate-spin w-4 h-4"/> : <Archive className="w-4 h-4"/>} 精修包
                </button>
                <button onClick={downloadAllComparisonsAsZip} disabled={isZippingComparison} className="px-6 py-4 bg-indigo-600 hover:bg-indigo-500 rounded-2xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/20">
                  {isZippingComparison ? <RefreshCw className="animate-spin w-4 h-4"/> : <Columns className="w-4 h-4"/>} 对比包
                </button>
              </div>
            </header>

            {/* 结果网格 */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
              {result.results.map((res, i) => (
                <div key={i} className="group relative rounded-[40px] overflow-hidden bg-white/5 border border-white/10 aspect-square cursor-zoom-in" onClick={() => setPreviewImage({url: res.url, label: res.label})}>
                  <img src={res.url} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent p-8 flex flex-col justify-end">
                    <div className="flex items-center gap-3">
                      <div className="bg-indigo-600 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest">{res.label}</div>
                      {config.addHuman && <div className="bg-white/10 px-3 py-2 rounded-full text-[9px] font-bold flex items-center gap-1"><UserPlus className="w-3 h-3"/> Lifestyle</div>}
                    </div>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); const l = document.createElement('a'); l.href=res.url; l.download=`${res.label}.png`; l.click(); }}
                    className="absolute top-6 right-6 p-4 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 对话区 */}
        <button onClick={() => setShowChat(!showChat)} className={`fixed bottom-10 right-10 p-5 rounded-3xl shadow-2xl z-50 transition-all ${showChat ? 'bg-red-500 rotate-90 scale-90' : 'bg-indigo-600 shadow-indigo-600/20'}`}><MessageSquare /></button>
        {showChat && (
          <div className="fixed bottom-32 right-10 w-80 md:w-[400px] h-[500px] bg-[#121212] border border-white/10 rounded-[40px] shadow-2xl flex flex-col z-50 overflow-hidden border-indigo-500/20">
             <header className="p-6 border-b border-white/5 bg-white/[0.02] text-xs font-bold uppercase tracking-widest opacity-60">总监诊室</header>
             <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                     <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-[13px] ${msg.role === 'user' ? 'bg-indigo-600' : 'bg-white/5 border border-white/10'}`}>{msg.text}</div>
                  </div>
                ))}
                <div ref={chatEndRef} />
             </div>
             <div className="p-6 border-t border-white/5 flex gap-2">
                <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} className="flex-1 bg-white/5 rounded-xl px-4 text-sm outline-none border border-white/10 focus:border-indigo-500 transition-all" />
                <button onClick={handleSendMessage} className="p-3 bg-indigo-600 rounded-xl"><ChevronRight /></button>
             </div>
          </div>
        )}

        {/* 全屏预览 */}
        {previewImage && (
          <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-8 cursor-zoom-out" onClick={() => setPreviewImage(null)}>
            <img src={previewImage.url} className="max-w-full max-h-full object-contain rounded-[40px] border border-white/10" />
            <div className="absolute top-8 right-8 flex gap-4">
              <button onClick={(e) => { e.stopPropagation(); const l = document.createElement('a'); l.href=previewImage.url; l.download='preview.png'; l.click(); }} className="p-4 bg-white/10 rounded-full"><Download /></button>
              <button onClick={() => setPreviewImage(null)} className="p-4 bg-white/10 rounded-full"><X /></button>
            </div>
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 px-8 py-3 bg-indigo-600 rounded-full text-xs font-black uppercase tracking-[0.4em]">{previewImage.label}</div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
